"""
title: Weather Fetcher
author: dev1
description: מביא נתוני מזג אוויר לפי עיר
version: 1.0.0
git_commit: a3f9c12
git_ref: v1.0.0
git_repo: https://gitlab.mycompany.com/group/openwebui-tools/tools/weather_fetcher
license: MIT
"""

import requests
from pydantic import BaseModel, Field


class Tools:

    class Valves(BaseModel):
        API_KEY: str = Field(default="", description="OpenWeatherMap API Key")
        UNITS: str = Field(default="metric", description="יחידות מידה: metric / imperial")

    def __init__(self):
        self.valves = self.Valves()

    def get_weather(self, city: str) -> str:
        """
        מחזיר נתוני מזג אוויר עבור עיר נתונה.

        :param city: שם העיר באנגלית
        :return: תיאור מזג האוויר
        """
        if not self.valves.API_KEY:
            return "❌ חסר API_KEY — הגדירי ב-Valves"

        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {"q": city, "units": self.valves.UNITS, "appid": self.valves.API_KEY}

        try:
            r = requests.get(url, params=params, timeout=8)
            r.raise_for_status()
            data = r.json()
            temp = data["main"]["temp"]
            desc = data["weather"][0]["description"]
            humidity = data["main"]["humidity"]
            return f"מזג אוויר ב-{city}: {desc}, {temp}°, לחות {humidity}%"
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return f"❌ עיר לא נמצאה: {city}"
            return f"❌ שגיאת API: {e}"
        except Exception as e:
            return f"❌ שגיאה: {e}"
