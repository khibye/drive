#!/usr/bin/env python3
"""
inject_version.py
─────────────────
מוזרק ע"י GitLab CI לפני כל build/tag.
מחליף placeholders ב-docstring של כל tool.py
עם נתוני git אמיתיים.

Placeholders שמוחלפים:
  __GIT_COMMIT__  →  short commit hash (8 תווים)
  __GIT_REF__     →  tag או branch name
  __GIT_REPO__    →  כתובת בסיס של ה-repo ב-GitLab

משתני סביבה (מסופקים אוטומטית ע"י GitLab CI):
  CI_COMMIT_SHORT_SHA   — hash מקוצר
  CI_COMMIT_REF_NAME    — branch או tag name
  CI_PROJECT_URL        — כתובת ה-repo
  TOOLS_DIR             — תיקיית ה-tools (ברירת מחדל: tools/)
"""

import os
import sys
from pathlib import Path


def get_env(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


def inject_version(tool_path: Path, commit: str, ref: str, repo_url: str) -> bool:
    """
    מחליף placeholders ב-tool.py אחד.
    מחזיר True אם בוצע שינוי.
    """
    original = tool_path.read_text(encoding="utf-8")
    updated = (
        original
        .replace("__GIT_COMMIT__", commit)
        .replace("__GIT_REF__", ref)
        .replace("__GIT_REPO__", repo_url)
    )
    if updated == original:
        print(f"  [skip]    {tool_path} — אין placeholders")
        return False

    tool_path.write_text(updated, encoding="utf-8")
    print(f"  [updated] {tool_path}")
    return True


def main():
    commit   = get_env("CI_COMMIT_SHORT_SHA", "dev")
    ref      = get_env("CI_COMMIT_REF_NAME",  "local")
    repo_url = get_env("CI_PROJECT_URL",       "https://gitlab.example.com/group/tools")
    tools_dir = Path(get_env("TOOLS_DIR", "tools"))

    if not tools_dir.exists():
        print(f"❌ תיקיית tools לא נמצאה: {tools_dir}")
        sys.exit(1)

    tool_files = sorted(tools_dir.rglob("tool.py"))
    if not tool_files:
        print(f"⚠️  לא נמצאו קבצי tool.py תחת {tools_dir}/")
        sys.exit(0)

    print(f"🔧 Injecting version info:")
    print(f"   commit:  {commit}")
    print(f"   ref:     {ref}")
    print(f"   repo:    {repo_url}")
    print(f"   tools:   {len(tool_files)} נמצאו\n")

    updated_count = 0
    for tool_file in tool_files:
        if inject_version(tool_file, commit, ref, repo_url):
            updated_count += 1

    print(f"\n✅ עודכנו {updated_count} מתוך {len(tool_files)} קבצים")


if __name__ == "__main__":
    main()
