#!/usr/bin/env python3
"""
build_catalog.py
────────────────
בונה דף HTML סטטי (catalog) לכל ה-tools ב-repo.
הדף מציג כל tool עם כפתור "Import to WebUI"
שעובד בדיוק כמו הקהילה הרשמית של OpenWebUI.

משתני סביבה:
  CI_PROJECT_URL       — כתובת ה-repo ב-GitLab
  CI_COMMIT_REF_NAME   — branch או tag name
  CI_COMMIT_SHORT_SHA  — short commit hash
  TOOLS_DIR            — תיקיית tools (ברירת מחדל: tools/)
  OUTPUT_FILE          — קובץ פלט (ברירת מחדל: public/index.html)
"""

import json
import os
import sys
from pathlib import Path
from html import escape


def get_env(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


def load_tool(tool_dir: Path) -> dict | None:
    meta_path = tool_dir / "meta.json"
    tool_path = tool_dir / "tool.py"

    if not tool_path.exists():
        return None

    meta = {}
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"  ⚠️  meta.json שגוי ב-{tool_dir.name}: {e}")

    return {
        "id":          meta.get("id", tool_dir.name),
        "title":       meta.get("title", tool_dir.name),
        "description": meta.get("description", ""),
        "category":    meta.get("category", "Other"),
        "author":      meta.get("author", ""),
        "version":     meta.get("version", "1.0.0"),
        "tags":        meta.get("tags", []),
        "dir":         tool_dir.name,
    }


CATEGORY_COLORS = {
    "API":        ("#E6F1FB", "#0C447C"),
    "Filesystem": ("#EAF3DE", "#27500A"),
    "DB":         ("#FAEEDA", "#633806"),
    "Utils":      ("#EEEDFE", "#3C3489"),
    "Other":      ("#F1EFE8", "#444441"),
}


def build_html(tools: list[dict], repo_url: str, ref: str, commit: str) -> str:
    repo_raw_base = f"{repo_url}/-/raw/{ref}"

    cards_html = ""
    for t in tools:
        raw_url   = f"{repo_raw_base}/tools/{t['dir']}/tool.py"
        bg, fg    = CATEGORY_COLORS.get(t["category"], CATEGORY_COLORS["Other"])
        tags_html = "".join(
            f'<span style="background:#f1efe8;color:#5f5e5a;font-size:11px;'
            f'padding:2px 8px;border-radius:10px;border:0.5px solid #d3d1c7">'
            f'{escape(tag)}</span>'
            for tag in t["tags"]
        )

        cards_html += f"""
        <div class="card" data-category="{escape(t['category'])}" data-title="{escape(t['title'].lower())}">
          <div class="card-header">
            <div>
              <div class="card-title">{escape(t['title'])}</div>
              <div class="card-meta">{escape(t['author'])} &nbsp;·&nbsp; v{escape(t['version'])}</div>
            </div>
            <span class="badge" style="background:{bg};color:{fg}">{escape(t['category'])}</span>
          </div>
          <div class="card-desc">{escape(t['description'])}</div>
          <div class="tags">{tags_html}</div>
          <div class="card-footer">
            <a class="btn-import" href="#" onclick="importTool('{escape(raw_url)}');return false">
              Import to WebUI
            </a>
            <a class="btn-source" href="{escape(repo_url)}/-/tree/{escape(ref)}/tools/{escape(t['dir'])}"
               target="_blank">מקור</a>
          </div>
        </div>"""

    categories = sorted({t["category"] for t in tools})
    filter_btns = '<button class="filter-btn active" onclick="filter(this,\'all\')">הכל</button>'
    for cat in categories:
        filter_btns += f'<button class="filter-btn" onclick="filter(this,\'{escape(cat)}\')">{escape(cat)}</button>'

    return f"""<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OpenWebUI Tools Catalog</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0 }}
  body {{ font-family: system-ui, sans-serif; background: #f8f8f6; color: #2c2c2a; line-height: 1.6 }}

  .topbar {{ background: #fff; border-bottom: 0.5px solid #d3d1c7; padding: 14px 32px;
             display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px }}
  .topbar h1 {{ font-size: 18px; font-weight: 500 }}
  .topbar-meta {{ font-size: 12px; color: #888780 }}

  .toolbar {{ padding: 20px 32px 0; display: flex; align-items: center; gap: 12px; flex-wrap: wrap }}
  .search {{ padding: 8px 12px; border: 0.5px solid #d3d1c7; border-radius: 8px;
             font-size: 14px; width: 240px; outline: none; background: #fff }}
  .search:focus {{ border-color: #888780 }}
  .filter-btn {{ padding: 6px 14px; border: 0.5px solid #d3d1c7; border-radius: 20px;
                 background: transparent; font-size: 13px; cursor: pointer; color: #5f5e5a }}
  .filter-btn:hover {{ background: #f1efe8 }}
  .filter-btn.active {{ background: #2c2c2a; color: #fff; border-color: #2c2c2a }}

  .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
           gap: 16px; padding: 24px 32px }}
  .card {{ background: #fff; border: 0.5px solid #d3d1c7; border-radius: 12px;
           padding: 16px 18px; display: flex; flex-direction: column; gap: 10px }}
  .card[hidden] {{ display: none }}
  .card-header {{ display: flex; justify-content: space-between; align-items: flex-start; gap: 8px }}
  .card-title {{ font-size: 15px; font-weight: 500 }}
  .card-meta {{ font-size: 12px; color: #888780; margin-top: 2px }}
  .badge {{ font-size: 11px; font-weight: 500; padding: 3px 10px; border-radius: 10px;
            white-space: nowrap }}
  .card-desc {{ font-size: 13px; color: #5f5e5a; flex: 1 }}
  .tags {{ display: flex; flex-wrap: wrap; gap: 5px }}
  .card-footer {{ display: flex; gap: 8px; margin-top: 4px }}
  .btn-import {{ flex: 1; padding: 8px; background: #2c2c2a; color: #fff; text-align: center;
                 border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 500 }}
  .btn-import:hover {{ background: #444441 }}
  .btn-source {{ padding: 8px 14px; border: 0.5px solid #d3d1c7; border-radius: 8px;
                 text-decoration: none; color: #5f5e5a; font-size: 13px }}
  .btn-source:hover {{ background: #f1efe8 }}

  .modal-bg {{ display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.45);
               align-items: center; justify-content: center; z-index: 100 }}
  .modal-bg.open {{ display: flex }}
  .modal {{ background: #fff; border-radius: 12px; padding: 24px; width: 440px; max-width: 90%;
            border: 0.5px solid #d3d1c7 }}
  .modal h2 {{ font-size: 16px; font-weight: 500; margin-bottom: 16px }}
  .modal label {{ font-size: 13px; color: #5f5e5a; display: block; margin-bottom: 6px }}
  .modal input {{ width: 100%; padding: 8px 10px; border: 0.5px solid #d3d1c7;
                  border-radius: 8px; font-size: 13px; outline: none; margin-bottom: 16px }}
  .modal input:focus {{ border-color: #888780 }}
  .modal-hint {{ font-size: 12px; color: #888780; margin-bottom: 16px; margin-top: -10px }}
  .modal-actions {{ display: flex; gap: 8px; justify-content: flex-end }}
  .btn-cancel {{ padding: 8px 16px; border: 0.5px solid #d3d1c7; border-radius: 8px;
                 background: transparent; font-size: 13px; cursor: pointer }}
  .btn-go {{ padding: 8px 20px; background: #2c2c2a; color: #fff; border: none;
             border-radius: 8px; font-size: 13px; font-weight: 500; cursor: pointer }}
  .btn-go:hover {{ background: #444441 }}

  .empty {{ display: none; padding: 48px; text-align: center; color: #888780;
            grid-column: 1 / -1 }}
  .count {{ font-size: 12px; color: #888780; padding: 0 32px }}
</style>
</head>
<body>

<div class="topbar">
  <h1>OpenWebUI Tools Catalog</h1>
  <span class="topbar-meta">
    {len(tools)} tools &nbsp;·&nbsp; ref: {escape(ref)} &nbsp;·&nbsp; commit: {escape(commit)}
  </span>
</div>

<div class="toolbar">
  <input class="search" type="search" placeholder="חיפוש tool..." oninput="search(this.value)">
  {filter_btns}
</div>

<p class="count" id="count" style="margin-top:12px">{len(tools)} tools</p>

<div class="grid" id="grid">
  {cards_html}
  <div class="empty" id="empty">לא נמצאו tools</div>
</div>

<div class="modal-bg" id="modalBg">
  <div class="modal">
    <h2>Import to WebUI</h2>
    <label>כתובת מופע ה-OpenWebUI שלך</label>
    <input type="url" id="owuiUrl" placeholder="https://your-openwebui.com"
           value="" oninput="saveUrl(this.value)">
    <p class="modal-hint">לדוגמה: http://localhost:3000 או https://ai.mycompany.com</p>
    <div class="modal-actions">
      <button class="btn-cancel" onclick="closeModal()">ביטול</button>
      <button class="btn-go" onclick="doImport()">Import</button>
    </div>
  </div>
</div>

<script>
  let pendingRawUrl = '';
  let activeCategory = 'all';
  let activeSearch = '';

  const OWUI_KEY = 'owui_url';

  function saveUrl(v) {{ localStorage.setItem(OWUI_KEY, v); }}

  function importTool(rawUrl) {{
    pendingRawUrl = rawUrl;
    document.getElementById('owuiUrl').value = localStorage.getItem(OWUI_KEY) || '';
    document.getElementById('modalBg').classList.add('open');
  }}

  function closeModal() {{ document.getElementById('modalBg').classList.remove('open'); }}

  function doImport() {{
    const owui = document.getElementById('owuiUrl').value.trim().replace(/\\/$/, '');
    if (!owui) {{ alert('הזיני כתובת OpenWebUI'); return; }}
    saveUrl(owui);
    const importUrl = owui + '/workspace/tools/import?url=' + encodeURIComponent(pendingRawUrl);
    window.open(importUrl, '_blank');
    closeModal();
  }}

  function filter(btn, cat) {{
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeCategory = cat;
    applyFilters();
  }}

  function search(q) {{
    activeSearch = q.toLowerCase();
    applyFilters();
  }}

  function applyFilters() {{
    const cards = document.querySelectorAll('.card');
    let visible = 0;
    cards.forEach(c => {{
      const catMatch = activeCategory === 'all' || c.dataset.category === activeCategory;
      const searchMatch = !activeSearch || c.dataset.title.includes(activeSearch) ||
                          c.textContent.toLowerCase().includes(activeSearch);
      const show = catMatch && searchMatch;
      c.hidden = !show;
      if (show) visible++;
    }});
    document.getElementById('count').textContent = visible + ' tools';
    document.getElementById('empty').style.display = visible === 0 ? 'block' : 'none';
  }}

  document.getElementById('modalBg').addEventListener('click', e => {{
    if (e.target === document.getElementById('modalBg')) closeModal();
  }});
</script>
</body>
</html>"""


def main():
    repo_url  = get_env("CI_PROJECT_URL", "https://gitlab.example.com/group/tools")
    ref       = get_env("CI_COMMIT_REF_NAME", "main")
    commit    = get_env("CI_COMMIT_SHORT_SHA", "dev")
    tools_dir = Path(get_env("TOOLS_DIR", "tools"))
    output    = Path(get_env("OUTPUT_FILE", "public/index.html"))

    if not tools_dir.exists():
        print(f"❌ תיקיית tools לא נמצאה: {tools_dir}")
        sys.exit(1)

    tool_dirs = sorted(d for d in tools_dir.iterdir() if d.is_dir())
    tools = [t for d in tool_dirs if (t := load_tool(d)) is not None]

    if not tools:
        print("⚠️  לא נמצאו tools עם tool.py")
        sys.exit(0)

    print(f"📦 נמצאו {len(tools)} tools: {[t['id'] for t in tools]}")

    output.parent.mkdir(parents=True, exist_ok=True)
    html = build_html(tools, repo_url, ref, commit)
    output.write_text(html, encoding="utf-8")
    print(f"✅ catalog נבנה: {output}")


if __name__ == "__main__":
    main()
