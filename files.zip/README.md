# OpenWebUI Tools Catalog

ספריית Tools פנימית ל-OpenWebUI, מנוהלת דרך GitLab.

## מבנה ה-repo

```
tools/
├── weather_fetcher/
│   ├── tool.py       ← קוד ה-tool בפורמט OpenWebUI
│   ├── meta.json     ← מטאדאטה (שם, גרסה, קטגוריה)
│   └── README.md     ← תיעוד למפתחים
├── file_reader/
│   └── ...
scripts/
├── inject_version.py ← מוזרק ע"י CI: git_commit / git_ref
└── build_catalog.py  ← בונה את דף ה-catalog
.gitlab-ci.yml        ← pipeline אוטומטי
```

## Convention גרסאות

### Tags
כל גרסה יציבה מתויגת:
```
git tag v1.2.0
git push origin v1.2.0
```

### מה מוטמע בקוד אוטומטית
ה-CI מזריק לתוך docstring של כל `tool.py`:

```python
"""
title: Weather Fetcher
version: 1.2.0
git_commit: a3f9c12    ← commit hash אמיתי
git_ref: v1.2.0        ← tag או branch
git_repo: https://gitlab.mycompany.com/group/tools/-/tree/v1.2.0/tools/weather_fetcher
"""
```

כך כל מי שפותח ב-OpenWebUI רואה בדיוק מאיזה commit הגיע ה-tool.

## זרימת עבודה למפתח

```
1. צור תיקייה חדשה:  tools/my_tool/
2. הוסף tool.py, meta.json, README.md
3. פתח Merge Request
4. Maintainer מאשר ו-merge ל-main
5. CI רץ אוטומטית → catalog מתעדכן
6. לגרסה יציבה: git tag v1.x.x
```

## ייבוא ל-OpenWebUI

1. היכנסי לדף ה-catalog (GitLab Pages של ה-repo)
2. לחצי "Import to WebUI" ליד ה-tool הרצוי
3. הזיני את כתובת המופע שלך (נשמרת לפעם הבאה)
4. ה-tool נפתח ישירות ב-Workspace > Tools

## הוספת tool חדש

### tool.py — חובה להתחיל עם docstring זה:
```python
"""
title: My Tool Name
author: your_name
description: תיאור קצר
version: 1.0.0
git_commit: __GIT_COMMIT__
git_ref: __GIT_REF__
git_repo: __GIT_REPO__/tools/my_tool
license: MIT
"""
```

> **חשוב:** אל תשני את `__GIT_COMMIT__` / `__GIT_REF__` / `__GIT_REPO__` — ה-CI מחליף אותם אוטומטית.

### meta.json:
```json
{
  "id": "my_tool",
  "title": "My Tool Name",
  "description": "תיאור קצר",
  "category": "API",
  "author": "your_name",
  "version": "1.0.0",
  "min_openwebui_version": "0.4.0",
  "tags": ["tag1", "tag2"]
}
```

קטגוריות זמינות: `API`, `Filesystem`, `DB`, `Utils`, `Other`
